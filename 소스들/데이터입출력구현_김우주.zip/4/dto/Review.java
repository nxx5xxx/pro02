package dto;
public class Review {
	private	String bno;
	private	String id;
	private	String onum;
	private	String b_date;
	private	String b_review;
	private	int b_score;
	public String getBno() {
		return bno;
	}
	public void setBno(String bno) {
		this.bno = bno;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getOnum() {
		return onum;
	}
	public void setOnum(String onum) {
		this.onum = onum;
	}
	public String getB_date() {
		return b_date;
	}
	public void setB_date(String b_date) {
		this.b_date = b_date;
	}
	public String getB_review() {
		return b_review;
	}
	public void setB_review(String b_review) {
		this.b_review = b_review;
	}
	public int getB_score() {
		return b_score;
	}
	public void setB_score(int b_score) {
		this.b_score = b_score;
	}
	
}
